import React from "react";
import { createDrawerNavigator } from "@react-navigation/drawer";
import HomeScreen from "../screens/HomeScreen";
import ProfileScreen from "../screens/ProfileScreen";
import MessagesScreen from "../screens/MessagesScreen";
import FavouriteScreen from "../screens/FavouriteScreen";


const Drawer = createDrawerNavigator();

const DrawerNavigator = () => {
  return (
    <Drawer.Navigator
        drawerType={'back'}
    >
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Msg" component={MessagesScreen} />
      <Drawer.Screen name="Profile" component={ProfileScreen} />
      <Drawer.Screen name="Fav" component={FavouriteScreen} />
      
    </Drawer.Navigator>
  );
}

export default DrawerNavigator;