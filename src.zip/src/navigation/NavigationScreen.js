import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import SplashScreen from  '../screens/SplashScreen';
import HomeScreen from  '../screens/HomeScreen';
import DrawerNavigator from './DrawerNavigator';

const Stack = createStackNavigator();

const transitionAnim = ({ current, next, layouts }) => {
  return {
    cardStyle: {
      transform: [
        {
          translateX: current.progress.interpolate({
            inputRange: [0, 1],
            outputRange: [layouts.screen.width, 0],
          }),
        },
        {
          scale: next
            ? next.progress.interpolate({
                inputRange: [0, 1],
                outputRange: [1, 0.9],
              })
            : 1,
        },
      ],
    }
  }
}




const App = () => {
  return (
    <NavigationContainer>
            <Stack.Navigator
                screenOptions={{
                  gestureEnabled: false,
                  headerShown: false
                }}
            >                      
                <Stack.Screen 
                    name="Splash" 
                    component={SplashScreen} 
                    options={{ cardStyleInterpolator: transitionAnim }}
                />
                <Stack.Screen 
                    name="Home" 
                    component={DrawerNavigator} 
                />
            </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;   