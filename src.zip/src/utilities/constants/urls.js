const urls = {
    BASE_URL: 'http://shibe.online/api/',
    GET_IMAGES: 'shibes?count='
    
};

export { urls };