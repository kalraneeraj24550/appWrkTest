const colors = {
  black1: '#000000',
  black2: '#3C5663',
  white1: '#FFFFFF',
  themeBackgroundColor: '#3c5663',
  yellowColor: '#e6ae48',
  skyblueColor: '#c8dae4',
  lightBlueColor: '#C8DAE4',
  lightGreenColor: '#C8DAE4'
};

export { colors };