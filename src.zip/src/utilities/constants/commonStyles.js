import { colors } from './index';
import { appData } from './appData';

const commonStyle = {


}

export { commonStyle };