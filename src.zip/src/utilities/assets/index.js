import BannerImage1 from '../assets/icons/banner2.png';
import BannerImage2 from '../assets/icons/banner3.jpg';
import menuIcon from '../assets/icons/menu.png';

export {
    BannerImage1,
    BannerImage2,
    menuIcon
}