

const toOpenDrawer = (navigation) => {
    navigation.openDrawer();
};

export {
    toOpenDrawer
};