import React, { Component } from 'react';
import { View, FlatList, Animated } from 'react-native';
import { commonStyle, colors, appData } from '../../utilities/constants';

class LoadingData extends Component {

    componentWillMount() {
        this.animatedValue = new Animated.Value(0);
    }

    renderAnimation() {
        this.animatedValue.setValue(0)
        Animated.timing(this.animatedValue, {
            toValue: 1,
            duration: 1000
        }).start(() => {
            this.renderAnimation()
        });
    }

    render() {
        this.renderAnimation()
        const flashLightMotion = this.animatedValue.interpolate({
            inputRange: [0, 1],
            outputRange: [-200, 300]
        });
        const animatedStyle = {
            marginLeft: flashLightMotion
        }
        return (
            <View
                style={styles.wholeViewStyle}
            >
                <View style={commonStyle.carouselWholeViewStyle}>
                    <FlatList
                        data={[{},{},{},{}]}
                        keyExtractor={(item, index) => index + 'data'}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        renderItem={({ item, index }) =>
                            <View style={commonStyle.sliderItemViewStyle} />        
                        }
                    />
                </View>

                <FlatList
                        data={[{},{},{},{},{},{}]}
                        keyExtractor={(item, index) => index + 'data'}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        renderItem={({ item, index }) =>
                            <View style={commonStyle.itemsInRowWholeViewStyle} />
                        }
                />
                <FlatList
                        data={[{},{},{},{},{},{}]}
                        keyExtractor={(item, index) => index + 'data'}
                        horizontal
                        showsHorizontalScrollIndicator={false}
                        renderItem={({ item, index }) =>
                            <View style={commonStyle.itemsInRowWholeViewStyle} />
                        }
                />
        
                <Animated.View
                    style={[styles.flashLightViewStyle, animatedStyle]}
                />

            </View>

        )
    }
}

const styles = {

   
    lineStyle: {
        height: 10,
        width: 180,
        marginLeft: 20,
        backgroundColor: colors.GRAY_LINES_COLOR,
        marginBottom: 10
    },

    flashLightViewStyle: {
        position: 'absolute',
        backgroundColor: colors.white1,
        height: appData.screenHeight + 500,
        width: 50,
        opacity: 0.2,
        transform: [{ rotate: '8deg' }]

    },

    myStyle: {
        transform: [{ rotate: '90deg' }]
    },

    // InnerView: {
    //     marginHorizontal: 15,
    //     backgroundColor: ,
    //     opacity: 0.3,
    //     borderColor: GRAY_LINES_COLOR,
    //     height: 200,
    //     borderWidth: 1,
    //     marginBottom: 15,
    //     paddingVertical: 15,
    //     paddingHorizontal: 15,
    //     borderRadius: 10
    // },


   
}


export { LoadingData };