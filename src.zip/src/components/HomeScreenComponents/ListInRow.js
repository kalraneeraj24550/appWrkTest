import React from 'react';
import { View, StyleSheet, ImageBackground  } from 'react-native';
import { BannerImage2 } from '../../utilities/assets';

const ListInRow = (props) => {
    return (
        <ImageBackground
            source={{ uri: props.item }}
            style={styles.containerStyle}
        >

        </ImageBackground>

    )
}

const styles = StyleSheet.create({

    containerStyle: {
        height: 120,
        width: 120,
        borderRadius: 5,
        backgroundColor: 'gray',
        marginRight: 10,
        overflow: 'hidden',
        elevation: 3
    }

}) 


export { ListInRow };