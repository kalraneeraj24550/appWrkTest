import React from 'react';
import { View, Text, StyleSheet, Image, ImageBackground, TouchableOpacity } from 'react-native';

const Header = (props) => {
    return (
        <View style={styles.containerStyle}>
            <TouchableOpacity
                activeOpacity={0.7}
                style={styles.iconContainerStyle}
                onPress={props.onLeftCornerPress}
            >
                <Image
                    source={props.leftCornerIcon}
                />
            </TouchableOpacity>    
        </View>
    )
}

const styles = StyleSheet.create({

    containerStyle: {
        height: 44,
    },

    iconContainerStyle: {
        height: 44,
        width: 44,
        justifyContent: 'center',
        alignItems: 'center'
    }
})



export { Header };