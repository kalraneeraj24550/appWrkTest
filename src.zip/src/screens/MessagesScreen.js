import React, { Component } from 'react';
import { ImageBackground, View, StyleSheet, Text } from 'react-native';
import { BannerImage1, menuIcon } from '../utilities/assets';
import { colors } from '../utilities/constants';
import { Header } from '../common';
import { toOpenDrawer } from '../utilities/helperFunctions';

class MessagesScreen extends Component {

    render() {
        return (
            
            <ImageBackground 
                style={styles.wholeViewStyle}
                source={BannerImage1}

            >
                <Header
                    leftCornerIcon={menuIcon}
                    onLeftCornerPress={() => toOpenDrawer(this.props.navigation)}
                />
                <View style={styles.innerViewStyle}>
                    <Text style={styles.dummyNameTextStyle}>Messages</Text>
                </View>
            </ImageBackground>
        )
    }
}

const styles = StyleSheet.create({

    wholeViewStyle: {
        flex: 1
    },

    innerViewStyle: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },

    dummyNameTextStyle: {
        fontSize: 20,
        color: colors.white1
    }

});


export default MessagesScreen;