import React, { Component } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground, Dimensions, ScrollView, FlatList } from 'react-native';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import { connect } from 'react-redux';
import { BannerImage2, BannerImage1, menuIcon } from '../utilities/assets';
import { ListInRow  } from '../components/HomeScreenComponents';
import { Header } from '../common/Header';
import { colors } from '../utilities/constants';
import { toOpenDrawer } from '../utilities/helperFunctions';
import { getImagesData } from '../store/actions';

class HomeScreen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            activeSlide: 0,
            popularData: [],
            bestData: [],
            topSellingData: []
        }
    }

    componentDidMount() {
        this.props.getImagesData(50);
    }

    static getDerivedStateFromProps(props, state) {
        console.log('props getttingg-====', props);
        if (props.getAllImageData.length > 0) {
            return {
                popularData: props.getAllImageData.filter((item, i) => i <= 4
                    && {
                    ...item,
                }
                ),

                bestData: props.getAllImageData.filter((item, i) => i <= 24
                    && {
                    ...item,
                }
                ),
                topSellingData: props.getAllImageData.filter((item, i) => i > 24
                    && {
                    ...item,
                }
                )
            }
        }
        return null;

    }

    handleClick() {
        this.props.navigation.openDrawer();
    }

    _renderItem = ({ item, index }) => {

        return (
            (index <= 4) &&
            <ImageBackground
                source={{ uri: item}}
                style={styles.sliderItemViewStyle}
            >

            </ImageBackground>
        );
    }

    onOpenDrawer() {

        toOpenDrawer(this.props.navigation)
    }

    renderDataInRow(type) {
        const { bestData, topSellingData } = this.state;
        return (
            <View>
                <Text style={styles.listHeadingViewTextStyle}>
                    {type}
                </Text>
                <View style={styles.itemsInRowWholeViewStyle}>
                    <FlatList
                        data={(type == 'Best Products') ? bestData : topSellingData}
                        showsHorizontalScrollIndicator={false}
                        horizontal
                        renderItem={({ item, index }) =>
                            <ListInRow 
                                item={item}
                            />
                        }
                    />
                </View>
            </View>
        )
    }

    get pagination() {
        const { entries, activeSlide } = this.state;
        return (
            <Pagination
                dotsLength={this.state.popularData.length}
                activeDotIndex={activeSlide}
                containerStyle={{ position: 'absolute', bottom: -10, alignSelf: 'center' }}
                dotStyle={{
                    width: 10,
                    height: 10,
                    borderRadius: 5,
                    marginHorizontal: 8,
                    backgroundColor: colors.black1
                }}
                inactiveDotStyle={{
                    backgroundColor: colors.white1
                }}
                
                inactiveDotOpacity={0.4}
            />
        );
    }

    render() {
        const { getAllImageData, loading } = this.props;
        const { popularData } = this.state;
        console.log('getImages data=====', getAllImageData)
        console.log('getImages data====loading=', loading)

        return (
            <ImageBackground
                source={BannerImage2}
                style={styles.wholeViewStyle}
            >
                <Header
                    leftCornerIcon={menuIcon}
                    onLeftCornerPress={this.onOpenDrawer.bind(this)}
                />

                <ScrollView>
                    <Text style={styles.listHeadingViewTextStyle}>
                        Popular
                    </Text>
                    <View style={styles.carouselWholeViewStyle}>
                        <Carousel
                            ref={(c) => { this._carousel = c; }}
                            data={popularData}
                            renderItem={this._renderItem}
                            sliderWidth={Dimensions.get('window').width}
                            itemWidth={Dimensions.get('window').width}
                            onSnapToItem={(index) => this.setState({ activeSlide: index })}
                            autoplay={true}
                            autoplayDelay={1000}
                            automaticallyAdjustContentInsets={true}
                            snapToStart={true}
                        />
                        {this.pagination}
                    </View>
                    {this.renderDataInRow('Best Products')}
                    {this.renderDataInRow('Top Selling')}
                </ScrollView>
            </ImageBackground>
        )
    }
}

const styles = StyleSheet.create({

    wholeViewStyle: {
        flex: 1,
    },

    carouselWholeViewStyle: {
        borderRadius: 15,
        overflow: 'hidden',
        marginTop: 15,
        marginBottom: 15
    },

    sliderItemViewStyle: {
        height: 200,
        padding: 15,
        marginHorizontal: 20,
        borderRadius: 7,
        overflow: 'hidden',
        backgroundColor: 'gray'
    },

    itemsInRowWholeViewStyle: {
        marginVertical: 15,
        marginHorizontal: 20
    },

    listHeadingViewTextStyle: {
        fontSize: 20,
        color: colors.black1,
        marginLeft: 20,
        fontWeight: 'bold'
    }

});

const mapStateToProps = ({ appInfo }) => {
    const {
        getAllImageData,
        loading
    } = appInfo;

    return {
        getAllImageData,
        loading
    };
};


export default connect(mapStateToProps, {
    getImagesData
})(HomeScreen);
