import React, { Component } from 'react';
import { ImageBackground,  StyleSheet } from 'react-native';
import { BannerImage1 } from '../utilities/assets';

class SplashScreen extends Component {
    
    componentDidMount() {
        setTimeout(() => { 
                  this.props.navigation.navigate('Home')
        } , 3000);
    }
    
    render() {
        return (
            <ImageBackground 
                style={styles.wholeViewStyle}
                source={BannerImage1}
            />

        )
    }
}

const styles = StyleSheet.create({

    wholeViewStyle: {
        flex: 1,
    },

});


export default SplashScreen;