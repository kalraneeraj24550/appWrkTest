import { actionTypes } from "../../utilities/constants";

const INITIAL_STATE = {
    getAllImageData: [],
    loading: false,

  
};


export default (state = INITIAL_STATE, action) => {
    switch (action.type) {

        case actionTypes.GET_IMAGES:
            return {
                ...state,
                loading: true
            }

        case actionTypes.GET_IMAGES_SUCCESS:
           
            return {
                ...state,
                loading: false,
                getAllImageData: action.payload
            }

        case actionTypes.GET_IMAGES_FAIL:
            return {
                ...state,
                loading: false,
                getAllImageData: []
            }
        // case actionTypes.HANDLE_INTERVAL_TIME:
        //     return {
        //         ...state,
        //         selectedTimeInterval: action.payload
        //     }

        default:
            return state;
            
    }
} 