import { BASE_URL } from "./types";

// export const getApiExecute = (url) => {
//     let header;
//     header = {
//         'Content-Type': 'application/json'
//     }
//     return new Promise((resolve, reject) => {    
//         fetch(url, {
//             method: 'GET',
//             headers: header
//         }).then(res => {
//                 statusCode = res.status
//                 return res.json()
//             })
//             .then(response => {
//                 resolve(response)

//             }).catch((err) => {
//                 reject(err)
//             })
//     })
// };




