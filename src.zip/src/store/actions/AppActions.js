import { actionTypes, urls } from '../../utilities/constants';

export const getImagesData = (data) => {

    return (dispatch) => {
        dispatch({
            type: actionTypes.GET_IMAGES
        });

        const url = `${urls.BASE_URL}${urls.GET_IMAGES}${data}&urls=true&httpsUrls=true`;
        fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }).then(res => res.json())
            .then(response => {
                console.log('response getting-----',response)
                dispatch({
                    type: actionTypes.GET_IMAGES_SUCCESS,
                    payload: response
                });
            })
            .catch(error => {
                dispatch({
                    type: actionTypes.GET_IMAGES_FAIL
                });
              
            },
            );
    }
}