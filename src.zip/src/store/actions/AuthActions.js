    // import { actionTypes } from '../../utilities/constants';

    // // export const storeLoginUserData = (data) => {
    // //     return {
    // //         type: actionTypes.STORE_LOGIN_USER_DATA,
    // //         payload: data
    // //     };
    // // };
